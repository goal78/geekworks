var postId = 0;
var inputJudge = true;
$('.loading').show();
setTimeout(function() {
	$('.loading').hide();
	$('.table').animate({
		opacity: 1
	});
}, 1000);

// 弹框点击提交按钮
$('.addPost').click(function(e) {
	e.stopPropagation();
	var allEmptyJudge = clickJudge();
	$('.newsArea').css({
		opacity: 0
	});
	// e.stopImmediatePropagation();
	if (inputJudge == false || allEmptyJudge == false) {
		return false;
	}

	$.ajax({
		url: '/admin',
		type: 'post',
		data: $('.addPostForm').serialize(),
		success: function(response, status, xhr) {
			$('.addNews').find('input[name="postId"]').val(0)
			$('.addNews').find('input[name="byEdit"]').val(false)
			$('#forTbody').html('');
			$.each(response, function(i, value) {

				$('.newsArea').css({
					opacity: 1
				});
				$('#forTbody').append('<tr><td class="postId">' + value.id + '</td><td class="postTitle">' + value.title +
					'</td><td class="postImg">' + '<img src="img/' + value.img + '">' + '</td><td class="postContent">' + value.content +
					'</td><td class="postTime">' + value.time + '</td><td class="postNav">' + value.nav + '</td><td>' +
					'<div class="btn-group"><button class="btn btn-xs btn-danger postCancel"><i class="glyphicon glyphicon-trash"></i></button><button  class="btn btn-xs btn-info postEdit"><i class="glyphicon glyphicon-pencil"></i></button></div>' + '</td></tr>');

			});
		},
		beforeSend: function() {
			$('.loading').animate({
				opacity: 1
			});
		}
	});

	$('input[type="reset"]').trigger('click');
	$('.addNews').animate({
		'opacity': 0
	});

	popFilterNone();
});

$(document).ajaxStart(function() {
	$('.loading').show();
});
$(document).ajaxStop(function() {
	$('.loading').hide();
});

// 正则表达式判断输入框
$('input[name=img]').blur(function() {
	var regJudge = /\w\.(jpg|gif|png|jpeg)$/;
	var imgInput = $(this).val();
	if (!regJudge.test(imgInput)) {
		$('.imgTip').show();
		inputJudge = false;
	}
}).focus(function() {
	$('.imgTip').hide();
	inputJudge = true;
});
$('input[name=title]').blur(function() {

	var titleInput = $(this).val();
	if (titleInput == '') {
		$('.titleTip').show();
		inputJudge = false;
	}
}).focus(function() {
	$('.titleTip').hide();
	inputJudge = true;
});
$('textarea[name=content]').blur(function() {

	var contentInput = $(this).val();
	if (contentInput == '') {
		$('.contentTip').show();
		inputJudge = false;
	}
}).focus(function() {
	$('.contentTip').hide();
	inputJudge = true;
});

// 输入框空判断
function clickJudge() {
	$('input[name=img]').trigger('blur');
	$('input[name=title]').trigger('blur');
	$('textarea[name=content]').trigger('blur');
}

// 除冒泡
$('.addNews').click(function(e) {
	e.stopPropagation();
});
// 弹框关闭按钮
$('.delete').click(function() {
	$('.addNews').animate({
		opacity: 0
	});
	$('input[name="nav"]').removeAttr('checked');
	$('input[type="reset"]').trigger('click');

	popFilterNone();
});


// 删除文章列表操作
$('tBody').delegate('.postCancel', 'click', function(e) {
	var trRemoved = $(this).closest('tr').find('.postId').text();

	$.ajax({
		url: '/admin',
		type: 'post',
		global: false,
		data: {
			postId: trRemoved,
			removeFlag: true
		},
		success: function(response, status, xhr) {

		}
	});
	$(this).closest('tr').css({
		'background': '#FF99CC'
	}).delay(200).fadeOut();
	e.stopPropagation();

});
// 点击编辑按钮
$('tBody').delegate('.postEdit', 'click', function(e) {
	e.stopPropagation();

	$('.addNews').animate({
		'opacity': 1
	});
	var postTitle = $(this).closest('tr').find('.postTitle').text();
	var postImg = $(this).closest('tr').find('.postImg img').attr('src').trim();
	postImg = postImg.slice(4);

	var postContent = $(this).closest('tr').find('.postContent').text();
	var postNav = $(this).closest('tr').find('.postNav').text().trim();
	postId = $(this).closest('tr').find('.postId').text();

	$('.addNews').find('input[name="title"]').val(postTitle);
	$('.addNews').find('input[name="img"]').val(postImg);
	$('.addNews').find('textarea[name="content"]').val(postContent);
	$('.addNews').find('input[name="postId"]').val(postId);
	$('.addNews').find('input[name="byEdit"]').val(true);

	popUpFilter();
	$('.postNav').removeAttr('checked')
	$('.postNav').each(function(i) {

		if ($(this).attr('value') == postNav) {

			$(this).attr('checked', 'checked');
		}
	});


});

// 左侧导航里添加写文章
$('.addNewPost').click(function(e) {
	postId = 0;
	$('.addNews').find('input[name="postId"]').val(postId);
	// $('.addNews').find('input[name="byEdit"]').val(false);

	e.stopPropagation();
	$('.addNews').animate({
		'opacity': 1
	}, 1000);
	popUpFilter();

});
// 弹框底部半透明黑色蒙版
$('.wholeScreen').click(function() {
	return false;
})

// 弹出添加新文章蒙版
function popUpFilter() {
	$('.wholeScreen').css({
		opacity: 0.6,
		zIndex: 4,

	});
}

function popFilterNone() {
	$('.wholeScreen').animate({
		opacity: 0,
		zIndex: 0,

	});
}