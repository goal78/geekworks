var express = require('express');
var router = express.Router();
var orm = require("orm");
var bodyParser = require('body-parser');
/* GET users listing. */
router.all('/', function(req, res, next) {
	orm.connect("mysql://root:@localhost/baidu", function(err, db) {
	if (err) throw err;

	var news = db.define("news", {
		id: {
			type: 'serial',
			key: true
		},
		nav: String,
		title: String,
		img: String,
		content: String,
		time: Date
	});
	if(req.body.navPassed){
		
		news.find({nav:req.body.navPassed}, function(err, result) {
		if (err) throw err;

		// res.charSet('utf-8');
		 // res.json(result);
		 setTimeout(function(){
		 	res.json(result);
		 },1000)
		 
		 // console.log(finalResult);
		 

	});
	} else {
		news.find({}, function(err, result) {
		if (err) throw err;

		// res.charSet('utf-8');
		 // res.json(result);
		 
		 res.render('baiduNews', {queryResult:result});
		 // console.log(finalResult);
		 

	});
	}
	
});
  
});

module.exports = router;
