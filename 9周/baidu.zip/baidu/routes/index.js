var express = require('express');
var router = express.Router();
var orm = require("orm");
var bodyParser = require('body-parser');



/* GET home page. */

router.all('/', function(req, res, next) {

	// res.render('admin', { title: 'Express' });
	// console.log(bodyParser.body)
	orm.connect("mysql://root:@localhost/baidu", function(err, db) {
		if (err) throw err;

		var news = db.define("news", {
			id: {
				type: 'serial',
				key: true
			},
			nav: String,
			title: String,
			img: String,
			content: String,
			time: Date
		});
		if (req.body.byEdit == 'true') {

			news.get(req.body.postId, function(err, updateRow) {
				if (err) throw err;
				updateRow.save({
					nav: req.body.nav,
					title: req.body.title,
					img: req.body.img,
					content: req.body.content,
					// time: new Date().getFullTime()
				}, function(err) {
					console.log("saved!");
					news.find({}, function(err, result) {
						if (err) throw err;

						// res.charSet('utf-8');

						setTimeout(function() {
							res.json(result);
						}, 1000)
					});
				});
			});


		} else if (req.body.removeFlag) {

			news.get(req.body.postId, function(err, removedItem) {
				removedItem.remove(function(err) {
					console.log("removed!");
				});
			});
		} else if (req.body.postId == 0) {

			news.create({
				nav: req.body.nav,
				title: req.body.title,
				img: req.body.img,
				content: req.body.content,
				time: new Date().toLocaleString()
			}, function(err) {
				if (err) throw err;
				news.find({}, function(err, result) {
					if (err) throw err;

					// res.charSet('utf-8');
					setTimeout(function() {
							res.json(result);
						}, 1000)
						// res.render('admin', {queryResult:result});
						// console.log(finalResult);


				});
			})
		} else {
			news.find({}, function(err, result) {
				if (err) throw err;

				// res.charSet('utf-8');
				// res.json(result);
				res.render('admin', {
					queryResult: result
				});
				// console.log(finalResult);


			});
		}

	});
});

module.exports = router;