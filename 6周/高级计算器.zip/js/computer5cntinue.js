var btn0 = document.getElementById('btn0');
var btn1 = document.getElementById('btn1');
var btn2 = document.getElementById('btn2');
var btn3 = document.getElementById('btn3');
var btn4 = document.getElementById('btn4');
var btn5 = document.getElementById('btn5');
var btn6 = document.getElementById('btn6');
var btn7 = document.getElementById('btn7');
var btn8 = document.getElementById('btn8');
var btn9 = document.getElementById('btn9');
var btnC = document.getElementById('btnC');
var btnTimes = document.getElementById('btnTimes');
var btnEqual = document.getElementById('btnEqual');
var btnDivide = document.getElementById('btnDivide');
var btnPlus = document.getElementById('btnPlus');
var btnMinus = document.getElementById('btnMinus');
var screenContent = document.getElementById('screenContent');
var btnPencent = document.getElementById('btnPercent');
var btnGenhao = document.getElementById('btnGenhao');
var btnDaoshu = document.getElementById('btnDaoshu');
var btnSquare = document.getElementById('btnSquare');
var btnTan = document.getElementById('btnTan');
var btnSin = document.getElementById('btnSin');
var btnCos = document.getElementById('btnCos');
var btnPai = document.getElementById('btnPai');
var btnReverse = document.getElementById('btnReverse');
var btnLog = document.getElementById('btnLog');
var btnLifang = document.getElementById('btnLifang');
var btnQuyu = document.getElementById('btnQuyu');
var btnBackspace = document.getElementById('btnBackspace');
var btnArray = [btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btnC, btnTimes, btnDivide, btnPlus, btnMinus, btnEqual, btnPoint, btnPercent, btnGenhao, btnSquare, btnDaoshu, btnBackspace, btnSin, btnCos, btnTan, btnPai, btnLifang, btnQuyu];


var btnNumber = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, '.', 'π'];
var specialOperator = ['√', '1/x', 'x^2', '百分数', 'x^3'];
var specialOperator2 = ['sin', 'cos', 'tan', 'log'];

var operatorArray = ['+', '-', 'x', '÷', '='];
var operatorArray2 = ['+', '-', 'x', '÷', '%'];

var lastClickBtn;
var beforeLastClickBtn;
var currentClickBtn = 0;
var result = 0;
var startIndex = 0;
var operatorCount = 0;
var screenFieldStartFor = '';
var sin = /sin/;
var cos = /cos/;
var tan = /tan/;

for (var i = 0; i < btnArray.length; i++) {
    // 事件绑定
    btnArray[i].onclick = function() {

        var btnText = this.innerHTML;
        currentClickBtn = parseFloat(btnText);
        var screenField = screenContent.innerHTML;
        var screenLengh = screenField.length;
        var matchSin = screenField.match(sin);
        if (specialOperator2.indexOf(btnText) >= 0) {
            screenContent.innerHTML = btnText;
            result = 0;
            operatorCount = 0;
        } else if ((screenField.match(tan) == 'tan' && specialOperator.indexOf(btnText) >= 0) || (screenField.match(tan) == 'tan' && specialOperator2.indexOf(btnText) >= 0) || (screenField.match(tan) == 'tan' && operatorArray2.indexOf(btnText) >= 0)) {
            screenContent.innerHTML += '';
        } else if ((screenField.match(sin) == 'sin' && specialOperator.indexOf(btnText) >= 0) || (screenField.match(sin) == 'sin' && specialOperator2.indexOf(btnText) >= 0) || (screenField.match(sin) == 'sin' && operatorArray2.indexOf(btnText) >= 0)) {
            screenContent.innerHTML += '';
        } else if ((screenField.match(cos) == 'cos' && specialOperator.indexOf(btnText) >= 0) || (screenField.match(cos) == 'cos' && specialOperator2.indexOf(btnText) >= 0) || (screenField.match(cos) == 'cos' && operatorArray2.indexOf(btnText) >= 0)) {
            screenContent.innerHTML += '';
        } else if (screenContent.innerHTML == '') {
            if (btnNumber.indexOf(currentClickBtn) >= 0 || btnText == '-') {
                screenContent.innerHTML = btnText;
            } else if (btnText == 'π') {
                screenContent.innerHTML = Math.PI.toFixed(4);
            }


        } else if (isNaN(beforeLastClickBtn) && lastClickBtn == 0 && !isNaN(btnText)) {
            return false;
        } else if (!isNaN(screenField) && parseFloat(screenField) < 0) {
            screenContent.innerHTML = screenField.slice(1);
        } else if (operatorCount == 0 && specialOperator.indexOf(btnText) >= 0) {
            if (btnText == '百分数') {
                result = parseFloat(screenField) / 100;


            } else if (btnText == '√') {
                result = Math.sqrt(parseFloat(screenField)).toFixed(2);

            } else if (btnText == '1/x' && screenField != 0) {
                result = 1 / parseFloat(screenField);
                result = result.toFixed(8);
            } else if (btnText == 'x^2') {
                result = parseFloat(screenField) * parseFloat(screenField);
            } else if (btnText == 'x^3') {
                result = parseFloat(screenField) * parseFloat(screenField) * parseFloat(screenField);
            }

            screenContent.innerHTML = result;
            result = 0;
            operatorCount = 0;


        } else if (btnText == '=' && screenField.match(sin)) {

            var slicePosition = screenField.indexOf('n');


            var newString = screenField.slice(slicePosition + 1);

            var arrSlice = Math.PI * parseInt(newString) / 180;


            result = Math.sin(arrSlice).toFixed(2);

            screenContent.innerHTML = result;
            result = 0;
        } else if (btnText == '=' && screenField.match(cos)) {

            var slicePosition = screenField.indexOf('s');


            var newString = screenField.slice(slicePosition + 1);

            var arrSlice = Math.PI * parseInt(newString) / 180;


            result = Math.cos(arrSlice).toFixed(2);

            screenContent.innerHTML = result;
            result = 0;
        } else if (btnText == '=' && screenField.match(tan)) {

            var slicePosition = screenField.indexOf('n');


            var newString = screenField.slice(slicePosition + 1);

            var arrSlice = Math.PI * parseInt(newString) / 180;


            result = Math.tan(arrSlice).toFixed(2);
            // alert(Math.tan(arrSlice));
            screenContent.innerHTML = result;
            result = 0;
        } else if ((btnNumber.indexOf(lastClickBtn) >= 0 || lastClickBtn == '修改') && operatorArray.indexOf(btnText) >= 0) {

            var splitPoint;
            if (operatorCount == 0) {

                screenFieldStartFor = screenField;



            } else {
                screenFieldStartFor = screenField.slice(screenLengh - 1 - startIndex);
            }

            for (var h = 0; h < screenFieldStartFor.length; h++) {
                if (operatorArray2.indexOf(screenFieldStartFor.charAt(h)) >= 0) {

                    operatorCount += 1;

                    if (operatorCount == 1) {

                        if (h == '0') {
                            result = parseFloat(screenFieldStartFor);

                        } else {

                            startIndex = h;
                            splitPoint = screenFieldStartFor.charAt(h);
                            var screenArr = screenFieldStartFor.split(splitPoint);
                            var x1 = screenArr[0];
                            var y1 = screenArr[1];
                            x1 = parseFloat(x1);
                            y1 = parseFloat(y1);

                            var method = splitPoint;

                            result = calculate(x1, y1, method);
                        }



                    } else if (operatorCount >= 2) {

                        x1 = result;


                        var method = screenFieldStartFor.charAt(h);
                        var y1 = screenFieldStartFor.slice(h + 1);

                        y1 = parseFloat(y1);
                        result = calculate(x1, y1, method);

                    }
                }
            }

            if (operatorArray2.indexOf(btnText) >= 0) {
                screenContent.innerHTML += btnText;
            } else if (btnText == '=') {
                screenContent.innerHTML = result;
                result = 0;
                operatorCount = 0;
            }



        } else if (btnText == '=' && isNaN(screenField) == false) {

            return false;
        } else if (lastClickBtn == '=' && btnNumber.indexOf(currentClickBtn) >= 0) {


            screenContent.innerHTML = btnText;
            result = 0;
            operatorCount = 0;

        } else if (operatorArray2.indexOf(lastClickBtn) >= 0 && operatorArray.indexOf(btnText) >= 0) {
            return false;

        } else if (btnText == '清零') {
            screenContent.innerHTML = 0;
            result = 0;
            operatorCount = 0;

        } else if (btnText == '修改') {

            screenContent.innerHTML = screenField.slice(0, screenLengh - 1);
        } else if ((btnText == 'π' && lastClickBtn == '清零') || (btnText == 'π' && btnNumber.indexOf(lastClickBtn) >= 0) || (btnText == 'π' && lastClickBtn == '=') || (btnText == 'π' && specialOperator.indexOf(lastClickBtn) >= 0)) {
            screenContent.innerHTML = Math.PI.toFixed(4);
        } else if (btnText == 'π') {
            screenContent.innerHTML += Math.PI.toFixed(4);
        } else if (lastClickBtn == '清零' && (btnNumber.indexOf(currentClickBtn) >= 0 || btnText == '-')) {

            screenContent.innerHTML = btnText;


        } else if (lastClickBtn == '清零' && operatorArray2.indexOf(btnText)) {


            screenContent.innerHTML += btnText;


        } else if (specialOperator.indexOf(lastClickBtn) >= 0) {
            if (btnText == 'π') {
                screenContent.innerHTML = Math.PI.toFixed(4);
            } else if (btnNumber.indexOf(currentClickBtn) >= 0) {
                screenContent.innerHTML = btnText;
            } else if (operatorArray2.indexOf(btnText)) {
                screenContent.innerHTML += btnText;
            }
        } else {
            screenContent.innerHTML += btnText;

        }


        if (btnNumber.indexOf(currentClickBtn) >= 0) {


            lastClickBtn = currentClickBtn;

        } else {

            lastClickBtn = btnText;
            beforeLastClickBtn = lastClickBtn;

        }


    }

};
// 计算公式函数

var calculate = function(x, y, operator) {
    var x = x;
    var y = y;
    var operator = operator;
    var result;
    if (operator == '+') {
        result = x + y;
    } else if (operator == 'x') {
        result = x * y;
    } else if (operator == '-') {
        result = x - y;
    } else if (operator == '%') {
        result = x % y;

    } else if (y != 0) {
        result = x / y;
        result = result.toFixed(2);
    } else if (y == 0 && x >= 0) {
        result = '正无穷大';
    } else if (y == 0 && x < 0) {
        result = '负无穷小'
    }
    return result;
}