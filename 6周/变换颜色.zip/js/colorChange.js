// 获得id元素
var changPart = document.getElementById('changePart');
var colorfulGuide = document.getElementById('colorfulGuide');
var hao123Tools = document.getElementById('hao123-tools');
var layoutContainer = document.getElementById('layoutContainer');
var headContainer = document.getElementsByClassName('hao123-tools-wrap')[0];

var aElements = headContainer.getElementsByTagName('a');
var aGuide = colorfulGuide.getElementsByTagName('a');

// 初始化变量
var changePartChildren = changePart.children;
// class初始内容储存到变量
var intialColorfulGuide = colorfulGuide.className;
var intialhao123Tools = hao123Tools.className;
var intialLayoutContainer = layoutContainer.className;

// localStorage获得最后一个点击主题
themeValue = localStorage.getItem('theme');

switch (themeValue) {
    case 'change1':
        layoutContainer.classList.toggle('layoutContainer');
        hao123Tools.classList.toggle('hao123Tools');
        colorfulGuide.classList.toggle('colorfulGuide');
        break;

    case 'change2':
        colorfulGuide.classList.toggle('colorfulGuide2');
        layoutContainer.classList.toggle('layoutContainer2');
        hao123Tools.classList.toggle('hao123Tools2');
        break;
    case 'change3':
        colorfulGuide.classList.toggle('colorfulGuide3');
        layoutContainer.classList.toggle('layoutContainer3');
        hao123Tools.classList.toggle('hao123Tools3');
        break;
    case 'change4':
        colorfulGuide.classList.toggle('colorfulGuide4');
        layoutContainer.classList.toggle('layoutContainer4');
        hao123Tools.classList.toggle('hao123Tools4');
        break;
    case 'change5':
        colorfulGuide.className = intialColorfulGuide;
        hao123Tools.className = intialhao123Tools;
        layoutContainer.className = intialLayoutContainer;

}

// 点击事件换肤
for (var i = 0; i < changePartChildren.length; i++) {

    changePartChildren[i].onclick = function(e) {
        colorfulGuide.className = intialColorfulGuide;
        hao123Tools.className = intialhao123Tools;
        layoutContainer.className = intialLayoutContainer;
        switch (this.id) {

            case 'change1':
                layoutContainer.classList.toggle('layoutContainer');
                hao123Tools.classList.toggle('hao123Tools');
                colorfulGuide.classList.toggle('colorfulGuide');
                for (var j = 0; j < aElements.length; j++) {
                    aElements[j].classList.add('aFont');

                }
                for (var p = 0; p < aGuide.length; p++) {
                    aGuide[p].classList.remove('aFont');

                }
                localStorage.setItem('theme', 'change1');

                break;

            case 'change2':

                colorfulGuide.classList.toggle('colorfulGuide2');
                layoutContainer.classList.toggle('layoutContainer2');
                hao123Tools.classList.toggle('hao123Tools2');
                for (var j = 0; j < aElements.length; j++) {
                    aElements[j].classList.remove('aFont');
                }
                for (var p = 0; p < aGuide.length; p++) {
                    aGuide[p].classList.remove('aFont');

                }
                localStorage.setItem('theme', 'change2');
                break;
            case 'change3':

                colorfulGuide.classList.toggle('colorfulGuide3');
                layoutContainer.classList.toggle('layoutContainer3');
                hao123Tools.classList.toggle('hao123Tools3');
                for (var j = 0; j < aElements.length; j++) {
                    aElements[j].classList.add('aFont');
                }
                for (var p = 0; p < aGuide.length; p++) {
                    aGuide[p].classList.add('aFont');

                }
                localStorage.setItem('theme', 'change3');

                break;
            case 'change4':

                colorfulGuide.classList.toggle('colorfulGuide4');
                layoutContainer.classList.toggle('layoutContainer4');
                hao123Tools.classList.toggle('hao123Tools4');

                for (var j = 0; j < aElements.length; j++) {
                    aElements[j].classList.add('aFont');

                }
                for (var p = 0; p < aGuide.length; p++) {
                    aGuide[p].classList.remove('aFont');

                }
                localStorage.setItem('theme', 'change4');
                break;
            case 'change5':

                colorfulGuide.className = intialColorfulGuide;
                hao123Tools.className = intialhao123Tools;
                layoutContainer.className = intialLayoutContainer;
                for (var j = 0; j < aElements.length; j++) {
                    aElements[j].classList.remove('aFont');

                }
                for (var p = 0; p < aGuide.length; p++) {
                    aGuide[p].classList.remove('aFont');

                }
                localStorage.setItem('theme', 'change5');

        }
    };
}
