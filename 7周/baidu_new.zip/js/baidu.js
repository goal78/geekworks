$(function() {
	// 导航消息点击
	$(".news").click(function(e) {

		$(".inform").show();

	});
	$(".delete").click(function(e) {

		$(".inform").hide();
		e.stopImmediatePropagation();
	});

	// 设置hover效果

	$("#forSetting").hover(function() {

		$(".setting").show();
	}, function() {
		$(".setting").hide();
	});

	// 导航更多点击
	$("#last").hover(function() {
		$(this).css({
			background: "#f9f9f9"

		}).find("a").css("color", "#555");
		$("#navClick").css("display", "block");
	}, function() {
		$(this).css({
			background: "#38f"

		}).find("a").css("color", "white");
		$("#navClick").css("display", "none");
	});

});
// 搜索框下部左侧导航栏目轮转点击
var liList = $("#nav-list").children("li");
var zIndex = 6;
var preIndex = 0;
var clickTarget = null;
liList.click(function() {

	var clickIndex = $(this).index();



	if (clickIndex == 0 && zIndex == 6 || clickIndex == clickTarget) {
		return false;
	} else {
		$("#content-inner").children("li").eq(clickIndex).css({
			"zIndex": zIndex,
			"top": 318,

		}).animate({
			"top": 0
		}, 1000);
		$("#content-inner").children("li").eq(preIndex).animate({
			"top": -318
		}, 1000);
console.log($("#contentInner").children("li"))
		preIndex = clickIndex;
		zIndex++;
		clickTarget = $(this).index();
	}

});

// 小图片hover显示折扣
$(".sites-list").find("li").hover(function() {
	$(this).find("h4").slideDown();
	
}, function() {
	$(this).find("h4").slideUp();
	
})