$(window).on('load', function() {
	waterfall();
	var dataImg = {
		data: [{
			'src': '0.jpg'
		}, {
			'src': '1.jpg'
		}, {
			'src': '2.jpg'
		}, {
			'src': '3.jpg'
		}, {
			'src': '4.jpg'
		}, {
			'src': '5.jpg'
		}, {
			'src': '6.jpg'
		}]
	}
	window.onscroll = function() {
		$.each(dataImg.data, function(index, value) {
			if (passLastBox()) {
				var imgNew = $('<img>').attr('src', './img/' + $(value).attr('src'));
				var imgWrapper = $('<div>').addClass('imgWrapper').append(imgNew);
				var box = $('<div>').addClass('box').append(imgWrapper);
				$('.container').append(box);
				setTimeout(waterfall, 2000);
			}
		});

	};
});



function waterfall() {
	var box = $('.box');
	var boxWidth = box.eq(0).width();
	var num = Math.floor($('.container').width() / boxWidth);
	var boxArrHeight = [];
	box.each(function(index, value) {
		var eachHeight = box.eq(index).height();

		if (index < num) {
			boxArrHeight[index] = eachHeight;
		} else {
			var minBoxHeight = Math.min.apply(null, boxArrHeight);

			var minIndex = $.inArray(minBoxHeight, boxArrHeight);
			var minBoxLeft = box.eq(minIndex).position().left;
			$(value).css({
				position: 'absolute',
				top: minBoxHeight,
				left: minBoxLeft,
				
			});
			boxArrHeight[minIndex] += box.eq(index).height();
		}



	});
}

function passLastBox() {
	var box = $('.box');
	var lastHeight = box.last().height();
	var halfLastHeight = lastHeight / 2;
	var lastTotalHeight = halfLastHeight + box.last().position().top;
	var documentPlusScroll = $(window).scrollTop() + $(document).height();
	return (lastTotalHeight < documentPlusScroll) ? true : false;
}