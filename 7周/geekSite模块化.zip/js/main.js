define(
	function(require, exports, module) {
		 require('jquery');
		
		var a =require('geekPictureAni');
		var b =require('headerAni');
		var c =require('lessonList');
		var d =require('roadPath');
		var e =require('learnSystem');
		var f =require('companies');
		var g =require('university');
		var h =require('media');
		 a.geekPictureAni();
		 b.headerAni();
		 c.lessonList();
		 d.roadPath();
		 e.learnSystem();
		 f.companies();
		 g.university();
		 h.media();



	}
);