// 头部搜索框变化
$('.formInput').focus(function() {
	$('.hoverInput').hide();
	$('.formSub').css("background", "#35b558 url(http://s1.jikexueyuan.com/common/images/topsearch-icon2_8c8d8b0.png) center center no-repeat");

});
$('.formInput').blur(function() {
	$('.hoverInput').show();
	$('.formSub').css("background", "url(http://s1.jikexueyuan.com/common/images/topsearch-icon_e1f5df2.png) center center no-repeat");

});

// 账户名鼠标悬浮效果
$('.accountName').hover(function() {
	$('.nameDown').show();
	$('.glyphicon-menu-down').addClass('glyphiconAni');
	$('.glyphicon-menu-down').removeClass('glyphiconAniDown');
}, function() {
	$('.nameDown').hide();
	$('.glyphicon-menu-down').addClass('glyphiconAniDown');
	$('.glyphicon-menu-down').removeClass('glyphiconAni');
});
$('.nameDown').hover(function() {
	$(this).css('display', 'block');
}, function() {
	$(this).hide();
});

// 左侧导航悬浮效果
var indexLi = '';
$('.leftArea').find('li').hover(function() {
	indexLi = '.item' + $(this).index();
	$(this).css('borderRight', 'none');
	$(this).css('borderLeft', '2px solid #35b558');
	$('.hoverItem').css("display", "none");
	$(".leftArea").find(indexLi).show();
}, function() {
	$(".leftArea").find(indexLi).hide();
	$(this).css('borderRight', '1px solid #ccc');
	$(this).css('borderLeft', '1px solid #ccc');
});

// 中间轮播部分

$('.pictureLeft').hover(function() {
	$(this).animate({
		"opacity": "1"
	})
}, function() {
	$(this).animate({
		"opacity": "0.6"
	})
});
$('.pictureRight').hover(function() {
	$(this).animate({
		"opacity": "1"
	})
}, function() {
	$(this).animate({
		"opacity": "0.6"
	})
});

// 图片左转
var pictureLength = $('.pictureList').find('a').length;
var childLengthPicture = pictureLength * 570;

var diffPicture = childLengthPicture - 570;

$('.pictureLeft').click(function() {
 
	pictureChangeLeft(1000);

});

$('.pictureRight').click(function() {

	pictureChangeRight(1000);

});

var timerLoad = setInterval(function() {
	pictureChangeLeft(1000);
}, 4000);
$('.middleArea').hover(function() {
	clearInterval(timerLoad);

	$('.pictureLeft').animate({'opacity':'0.6'});
	$('.pictureRight').animate({'opacity':'0.6'});
}, function() {
	$('.pictureLeft').animate({opacity:0});
	$('.pictureRight').animate({opacity:0});
	timerLoad = setInterval(function() {
		pictureChangeLeft(1000);
	}, 4000);
});



// 图片左转和右转函数
function pictureChangeLeft(intervalTime) {

	$('.pageChange a').css('background', 'white');
	var pictureMarginLeft = $('.pictureList').css('marginLeft');

	pictureMarginLeft = parseInt(pictureMarginLeft);
	var indexPicture = Math.abs(pictureMarginLeft);
	var indexPictureNow = (indexPicture / 570) + 1;

	if ((indexPicture / 570) == 4) {

		$('.pageChange a:eq(0)').css('background', '#35b558');
	} else if ((indexPicture / 570) == 5) {

		$('.pageChange a:eq(1)').css('background', '#35b558');
	} else {
		$('.pageChange a:eq(' + indexPictureNow + ')').css('background', '#35b558');
	}


	var numInner = $('.pictureInner').size();
	if (Math.abs(pictureMarginLeft) == diffPicture && numInner == 1) {
		var cloneListPicture = $('.pictureInner').clone();


		$('.pictureInner').after(cloneListPicture);
		$('.pictureList:not(:animated').animate({
			marginLeft: pictureMarginLeft - 570
		}, intervalTime);
	} else if (Math.abs(pictureMarginLeft) == childLengthPicture) {



		$('.pictureList').css('marginLeft', '0');
		$('.pictureInner:eq(1)').remove();
		$('.pictureList:not(:animated)').animate({
			marginLeft: -570
		}, intervalTime);

	} else {
		$('.pictureList:not(:animated)').animate({
			marginLeft: pictureMarginLeft - 570
		}, intervalTime);

	}
}

function pictureChangeRight(intervalTime) {
	$('.pageChange a').css('background', 'white');
	var pictureMarginLeft = $('.pictureList').css('marginLeft');
	pictureMarginLeft = parseInt(pictureMarginLeft);
	var indexPicture = Math.abs(pictureMarginLeft);
	var indexPictureNow = (indexPicture / 570) - 1;
	var numInner = $('.pictureInner').size();
	$('.pageChange a:eq(' + indexPictureNow + ')').css('background', '#35b558');

	if (pictureMarginLeft == 0 && numInner == 1) {
		var cloneListPicture = $('.pictureInner').clone();


		$('.pictureInner').before(cloneListPicture);
		$('.pictureList').css('marginLeft', -childLengthPicture + 'px');


		$('.pictureList:not(:animated)').animate({
			marginLeft: -childLengthPicture + 570
		}, intervalTime);
	} else if (pictureMarginLeft == -diffPicture) {

		$('.pictureInner:eq(1)').remove();

		$('.pictureList:not(:animated)').animate({
			marginLeft: pictureMarginLeft + 570
		}, intervalTime);



	} else {
		$('.pictureList:not(:animated)').animate({
			marginLeft: pictureMarginLeft + 570
		}, intervalTime);

	}
}
// 图片右转


// 课程浮动效果
var indexLi = 0;
var zindex = 303;
$('.courseNav').find('li').hover(function() {

	if ($(this).parent().find('li:first') != $(this) && $(this).parent().find('li:first').hasClass('on')) {
		$(this).parent().find('li:first').removeClass('on');
	}

	indexLi = $(this).index();
	$(this).addClass('on');

	$('.lesson' + indexLi).css('zIndex', zindex);
	zindex++

}, function() {
	$(this).removeClass('on');


});

$('.lesson').find('.liInner').hover(function() {
	$(this).css('zIndex', '500');
	$(this).find('p').slideDown();
}, function() {
	$(this).find('p').slideUp();
	$(this).css('zIndex', '400');

});

$('.picture').hover(function(){
$(this).find('imgInner').animate({opacity:0.3});
$(this).find('.videoIcon').animate({opacity:1});
$(this).find('.heart').animate({opacity:1});

},function(){
	$(this).find('imgInner').animate({opacity:0});
$(this).find('.videoIcon').animate({opacity:0});
$(this).find('.heart').animate({opacity:0});
})



// 路线图浮动效果
$('.projectBody a').hover(function() {

	$(this).find('button').css({
		color: 'white',
		background: '#35b558',
		transition: 'all 1s'
	}, 1000);
}, function() {

	$(this).find('button').css({
		color: '#35b558',
		background: '#f3fff6',
		transition: 'all 1s'
	}, 1000);
});

// 知识体系

$('.unit').hover(function() {
	$(this).find('.unitInner').addClass('aRotate');
	$(this).find('.front').addClass('aRotate1');
	$(this).find('.back').addClass('aRotate2');
	$(this).find('.unitInner').removeClass('aRotateBack');
	$(this).find('.front').removeClass('aRotate1back');
	$(this).find('.back').removeClass('aRotate2back');
}, function() {
	$(this).find('.unitInner').addClass('aRotateBack');
	$(this).find('.front').addClass('aRotate1back');
	$(this).find('.back').addClass('aRotate2back');

	$(this).find('.unitInner').removeClass('aRotate');
	$(this).find('.front').removeClass('aRotate1');
	$(this).find('.back').removeClass('aRotate2');

});
// 战略合作企业

$('.enterpriseBody').hover(function() {
	$('.companyLeft').animate({
		opacity: 1
	});
	$('.companyRight').animate({
		opacity: 1
	});
}, function() {
	$('.companyLeft').animate({
		opacity: 0
	});
	$('.companyRight').animate({
		opacity: 0
	});
})

var childLengthCompany = $('.companyList').find('a').length * 160;

var diffCompany = childLengthCompany - 960;

$('.companyLeft').click(function() {
	var companyMarginLeft = $('.companyList').css('marginLeft');
	companyMarginLeft = parseInt(companyMarginLeft);
	var numInner = $('.companyListInner').size();
	if (Math.abs(companyMarginLeft) == diffCompany && numInner == 1) {
		var cloneList = $('.companyListInner').clone();


		$('.companyListInner').after(cloneList);
		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft - 160
		});
	} else if (Math.abs(companyMarginLeft) == childLengthCompany) {



		$('.companyList').css('marginLeft', '0');
		$('.companyListInner:eq(1)').remove();
		$('.companyList:not(:animated)').animate({
			marginLeft: -160
		});

	} else {
		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft - 160
		});

	}

});



$('.companyRight').click(function() {
	var companyMarginLeft = $('.companyList').css('marginLeft');
	companyMarginLeft = parseInt(companyMarginLeft);
var numInner = $('.companyListInner').size();
	if (companyMarginLeft == 0 && numInner == 1) {
		var cloneList = $('.companyListInner').clone();


		$('.companyListInner').before(cloneList);
		$('.companyList').css('marginLeft', -childLengthCompany + 'px');


		$('.companyList:not(:animated)').animate({
			marginLeft: -childLengthCompany + 160
		});
	} else if (companyMarginLeft == -diffCompany) {

		$('.companyListInner:eq(1)').remove();

		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft + 160
		});



	} else {
		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft + 160
		});

	}

});

// 合作院校
// 左右箭头效果
$('.universityBody').hover(function() {

	$('.universityLeft').animate({
		opacity: 1
	});
	$('.universityRight').animate({
		opacity: 1
	});
}, function() {
	$('.universityLeft').animate({
		opacity: 0
	});
	$('.universityRight').animate({
		opacity: 0
	});
})

// 合作院校翻转效果
var universityLength = $('.universityList').find('a').length * 136;

var diffuniversity = universityLength - 952;

$('.universityLeft').click(function() {
	var universityMarginLeft = $('.universityList').css('marginLeft');
	universityMarginLeft = parseInt(universityMarginLeft);
var numInner = $('.universityListInner').size();
	if (Math.abs(universityMarginLeft) == diffuniversity && numInner == 1) {

		var cloneUniversityInner = $('.universityListInner').clone();

		$('.universityListInner').after(cloneUniversityInner);
		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft - 136
		});
	} else if (Math.abs(universityMarginLeft) == universityLength) {


		$('.universityList').css('marginLeft', '0');
		$('.universityListInner:eq(1)').remove();
		$('.universityList:not(:animated)').animate({
			marginLeft: -136
		});

	} else {
		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft - 136
		});

	}

});



$('.universityRight').click(function() {
	var universityMarginLeft = $('.universityList').css('marginLeft');
	universityMarginLeft = parseInt(universityMarginLeft);
var numInner = $('.universityListInner').size();
	if (universityMarginLeft == 0 && numInner == 1) {
		var cloneUniversityRight = $('.universityListInner').clone();


		$('.universityListInner').before(cloneUniversityRight);
		$('.universityList').css('marginLeft', -universityLength + 'px');


		$('.universityList:not(:animated)').animate({
			marginLeft: -universityLength + 136
		});
	} else if (universityMarginLeft == -diffuniversity) {

		$('.universityListInner:eq(1)').remove();

		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft + 136
		});



	} else {
		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft + 136
		});

	}

});
// 媒体左右箭头轮转
$('.mediaReportBody').hover(function() {
	$('.mediaLeft').animate({
		opacity: 1
	});
	$('.mediaRight').animate({
		opacity: 1
	});
}, function() {
	$('.mediaLeft').animate({
		opacity: 0
	});
	$('.mediaRight').animate({
		opacity: 0
	});
})



var childLength = $('.mediaList').find('a').length * 160;

var diff = childLength - 960;

$('.mediaLeft').click(function() {
	var mediaMarginLeft = $('.mediaList').css('marginLeft');
	mediaMarginLeft = parseInt(mediaMarginLeft);
	var numInner = $('.mediaListInner').size();
	if (Math.abs(mediaMarginLeft) == diff && numInner == 1) {
		var cloneList = $('.mediaListInner').clone();


		$('.mediaListInner').after(cloneList);
		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft - 160
		});
	} else if (Math.abs(mediaMarginLeft) == childLength) {



		$('.mediaList').css('marginLeft', '0');
		$('.mediaListInner:eq(1)').remove();
		$('.mediaList:not(:animated)').animate({
			marginLeft: -160
		});

	} else {
		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft - 160
		});

	}

});



$('.mediaRight').click(function() {
	var mediaMarginLeft = $('.mediaList').css('marginLeft');
	mediaMarginLeft = parseInt(mediaMarginLeft);
var numInner = $('.mediaListInner').size();
	if (mediaMarginLeft == 0 && numInner == 1) {
		var cloneList = $('.mediaListInner').clone();


		$('.mediaListInner').before(cloneList);
		$('.mediaList').css('marginLeft', -childLength + 'px');


		$('.mediaList:not(:animated)').animate({
			marginLeft: -childLength + 160
		});
	} else if (mediaMarginLeft == -diff) {

		$('.mediaListInner:eq(1)').remove();

		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft + 160
		});



	} else {
		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft + 160
		});

	}

});