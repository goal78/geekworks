define(
	function(require, exports, module) {

		exports.university = function (){
			// 合作院校
// 左右箭头效果
$('.universityBody').hover(function() {

	$('.universityLeft').animate({
		opacity: 1
	});
	$('.universityRight').animate({
		opacity: 1
	});
}, function() {
	$('.universityLeft').animate({
		opacity: 0
	});
	$('.universityRight').animate({
		opacity: 0
	});
})

// 合作院校翻转效果
var universityLength = $('.universityList').find('a').length * 136;

var diffuniversity = universityLength - 952;

$('.universityLeft').click(function() {
	var universityMarginLeft = $('.universityList').css('marginLeft');
	universityMarginLeft = parseInt(universityMarginLeft);
var numInner = $('.universityListInner').size();
	if (Math.abs(universityMarginLeft) == diffuniversity && numInner == 1) {

		var cloneUniversityInner = $('.universityListInner').clone();

		$('.universityListInner').after(cloneUniversityInner);
		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft - 136
		});
	} else if (Math.abs(universityMarginLeft) == universityLength) {


		$('.universityList').css('marginLeft', '0');
		$('.universityListInner:eq(1)').remove();
		$('.universityList:not(:animated)').animate({
			marginLeft: -136
		});

	} else {
		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft - 136
		});

	}

});



$('.universityRight').click(function() {
	var universityMarginLeft = $('.universityList').css('marginLeft');
	universityMarginLeft = parseInt(universityMarginLeft);
var numInner = $('.universityListInner').size();
	if (universityMarginLeft == 0 && numInner == 1) {
		var cloneUniversityRight = $('.universityListInner').clone();


		$('.universityListInner').before(cloneUniversityRight);
		$('.universityList').css('marginLeft', -universityLength + 'px');


		$('.universityList:not(:animated)').animate({
			marginLeft: -universityLength + 136
		});
	} else if (universityMarginLeft == -diffuniversity) {

		$('.universityListInner:eq(1)').remove();

		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft + 136
		});



	} else {
		$('.universityList:not(:animated)').animate({
			marginLeft: universityMarginLeft + 136
		});

	}

});

		}


	}
);