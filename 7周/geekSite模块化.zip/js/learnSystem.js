define(
	function(require, exports, module) {

		exports.learnSystem = function (){
			// 知识体系

$('.unit').hover(function() {
	$(this).find('.unitInner').addClass('aRotate');
	$(this).find('.front').addClass('aRotate1');
	$(this).find('.back').addClass('aRotate2');
	$(this).find('.unitInner').removeClass('aRotateBack');
	$(this).find('.front').removeClass('aRotate1back');
	$(this).find('.back').removeClass('aRotate2back');
}, function() {
	$(this).find('.unitInner').addClass('aRotateBack');
	$(this).find('.front').addClass('aRotate1back');
	$(this).find('.back').addClass('aRotate2back');

	$(this).find('.unitInner').removeClass('aRotate');
	$(this).find('.front').removeClass('aRotate1');
	$(this).find('.back').removeClass('aRotate2');

});
		}


	}

);