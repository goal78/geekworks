//面向对象编程改造:

// a. 采用设计模式单例，模块化编程：
// b. 分别是 1.newsPop 2.hoverSetting 3.moreHover 4.pressChange 5.hoverDiscount 区块

// 1.导航消息点击

var newsPop = {
	init: function() {
		var me = this;
		me.render();
		me.bind();
	},
	render: function() {
		var me = this;
		me.news = $(".news");
		me.delete = $(".delete");
		me.inform = $(".inform");
	},
	bind: function() {
		var me = this;
		me.news.click(function(e) {

			me.inform.show();

		});
		me.delete.click(function(e) {

			me.inform.hide();
			e.stopImmediatePropagation();
		});
	}
};
newsPop.init();
// 2.设置hoverSetting效果

$("#forSetting").hover(function() {

	$(".setting").show();
}, function() {
	$(".setting").hide();
});

var hoverSetting = {
	init: function() {
		var me = this;
		me.render();
		me.bind();
	},
	render: function() {
		var me = this;
		me.forSetting = $("#forSetting");
		me.setting = $(".setting");

	},
	bind: function() {
		var me = this;
		me.forSetting.hover(function() {

			me.setting.show();
		}, function() {
			me.setting.hide();
		});
	}
};
hoverSetting.init();
// 3.导航更多点击


var moreHover = {
	init: function() {
		var me = this;
		me.render();
		me.bind();
	},
	render: function() {
		var me = this;
		me.last = $("#last");
		me.navClick = $("#navClick");

	},
	bind: function() {
		var me = this;
		me.last.hover(function() {
			$(this).css({
				background: "#f9f9f9"

			}).find("a").css("color", "#555");
			me.navClick.css("display", "block");
		}, function() {
			$(this).css({
				background: "#38f"

			}).find("a").css("color", "white");
			me.navClick.css("display", "none");
		});
	}
};
moreHover.init();
// 4.搜索框下部左侧导航栏目轮转点击
var pressChange = {
	init: function() {
		var me = this;
		me.render();
		me.bind();
	},
	bind: function() {
		var me = this;
		me.navList.click(function() {

			var clickIndex = $(this).index();

			if (clickIndex == 0 && me.zIndex == 6 || clickIndex == me.clickTarget) {
				return false;
			} else {
				me.contentInner.eq(clickIndex).css({
					"zIndex": me.zIndex,
					"top": 318,

				}).animate({
					"top": 0
				}, 1000);
				me.contentInner.eq(me.preIndex).animate({
					"top": -318
				}, 1000);

				me.preIndex = clickIndex;
				me.zIndex++;
				console.log($("#contentInner").children("li"))
				me.clickTarget = $(this).index();
				console.log('fdf')

			}

		});

	},
	render: function() {
		var me = this;
		me.navList = $("#nav-list").children("li");
		me.zIndex = 6;
		me.preIndex = 0;
		me.clickTarget = null;
		me.contentInner = $("#content-inner").children("li");

	}
}
pressChange.init();



// 5.小图片hover显示折扣
// 
var hoverDiscount = {
	init: function() {
		var me = this;
		me.render();
		me.bind();
	},
	render: function() {
		var me = this;
		me.sitesListLi = $(".sites-list").find("li");

	},
	bind: function() {
		var me = this;
		me.sitesListLi.hover(function() {
			$(this).find("h4").slideDown();

		}, function() {
			$(this).find("h4").slideUp();

		});
	}
};
hoverDiscount.init();