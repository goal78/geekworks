<?php 
header("Content-type:application/json;charset=utf8");


// 初始化数据库
$conn = mysql_connect('localhost','root','');
if(!$conn){
 	die('cound not connect'.mysql_error());
}else{
mysql_select_db('baidu',$conn);
// 数据库语句

$navQuery = isset($_REQUEST['nav'])?$_REQUEST['nav']:'';

// 数据库新闻列表返回到前端
 	 $sql2 = "SELECT * FROM `news` WHERE `nav`= '".$navQuery."'";
 	 mysql_query("set names utf8");
 	 $result2 = mysql_query($sql2,$conn);
 	 $arrResult = array();
 	while($row = mysql_fetch_array($result2)){
 		array_push($arrResult,array("id"=>$row["id"],"nav"=>$row["nav"],"title"=>$row["title"],"img"=>$row["img"],"content"=>$row["content"],"time"=>$row["time"],));
 	}
 	sleep(1);
 	echo json_encode($arrResult);
 }

mysql_close($conn);

?>