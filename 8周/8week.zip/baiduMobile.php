<?php 
header("Content-type:application/json;charset=utf8");


// 初始化数据库
$conn = mysql_connect('localhost','root','');
if(!$conn){
 	die('cound not connect'.mysql_error());
}else{
mysql_select_db('baidu',$conn);
// 数据库语句
if(!isset($_REQUEST['load'])){
$nav = isset($_REQUEST['nav'])?$_REQUEST['nav']:'';
$content = isset($_REQUEST['content'])?$_REQUEST['content']:'';
$img =isset($_REQUEST['img'])?$_REQUEST['img']:'';
$title = isset($_REQUEST['title'])?$_REQUEST['title']:'';
$postId =isset($_REQUEST['postId'])?$_REQUEST['postId']:'';
$removeFlag = isset($_REQUEST['removeFlag'])?$_REQUEST['removeFlag']:'';


if($postId == 0){
	// 插入前端增加的新闻项目
$sql = "INSERT INTO `news`(`nav`, `title`, `img`, `content`) VALUES ('".$nav."','".$content."','".$img."','".$title."')";
mysql_query('set names "utf8"');
$result = 	mysql_query($sql,$conn);
if(!$result){
 		die('数据库错误'.mysql_error());
} 
}else if($removeFlag){
	$sqlRemove = "DELETE FROM `news` WHERE id=".$postId;
	mysql_query('set names "utf8"');
	$resultRemove = mysql_query($sqlRemove,$conn);
	if(!$resultRemove){
		die('数据库错误'.mysql_error());
	}
}else{
	$sqlUpdate = "UPDATE `news` SET `nav`='".$nav."',`title`='".$title."',`img`='".$img."',`content`='".$content."' WHERE `id`= '".$postId."'";
	mysql_query('set names "utf8"');
	$resultUpdate = mysql_query($sqlUpdate,$conn);
	if(!$resultUpdate){
		die('数据库错误'.mysql_error());
	}
}

	
}
// 数据库新闻列表返回到前端
 	 $sql2 = "SELECT * FROM `news`";
 	 mysql_query("set names utf8");
 	 $result2 = mysql_query($sql2,$conn);
 	 $arrResult = array();
 	while($row = mysql_fetch_array($result2)){
 		array_push($arrResult,array("id"=>$row["id"],"nav"=>$row["nav"],"title"=>$row["title"],"img"=>$row["img"],"content"=>$row["content"],"time"=>$row["time"],));
 	}
 	
 	// foreach($arrResult as $key=>$v){
 	// 	print($v);
 	// 	$arrResult[$key] = urlencode($v);
 	// }
 	// echo urldecode(json_encode($arrResult));
 	sleep(1);
 	echo json_encode($arrResult);
 }

mysql_close($conn);

?>