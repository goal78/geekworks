-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-10-30 05:17:04
-- 服务器版本： 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baidu`
--
CREATE DATABASE IF NOT EXISTS `baidu` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `baidu`;

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

CREATE TABLE `news` (
  `id` int(10) NOT NULL,
  `nav` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`id`, `nav`, `title`, `img`, `content`, `time`) VALUES
(131, '推荐', '习近平：十三五规划尊重经济规律 走出中等收入国家陷阱', 'n1.jpg', '民生与消费成为走出中等收入国家陷阱的重要支撑，而民生与消费的持续动力则来自社会经济领域全方位的...', '2015-10-29 00:23:45'),
(137, '本地', '联赛杯-鲁尼点球战射失 曼联不敌英冠队出局', 'n2.jpg', '鲁尼、卡里克和阿什利-扬在点球战中先后射失。', '2015-10-29 00:36:20'),
(138, '本地', '"虐粉狂魔"霍建华:不愿分享感情 别试图了解我', 'n3.jpg', '搜狐娱乐讯（郝困/主笔 蓝本/视频 玄反影/摄影） 霍建华人气太高了。在《他来了请闭眼》 【观...', '2015-10-29 00:46:54'),
(140, '本地', '国际财经头条:大众三季度亏25亿欧元 15年来首次季度亏损', 'n5.jpg', '因“尾气门”丑闻引发的巨额费用，大众公司经历了15年来的首次季度盈利亏损。', '2015-10-29 01:14:13'),
(142, '', '台湾选举期陆客赴台或减少 国台办:台处敏感期', 'n4.jpg', '最近一段时间，台湾盛传大陆有关部门将在年底台湾选举的时候减少陆客到台湾旅游，请你证实。', '2015-10-29 07:56:16'),
(143, '娱乐', '中东部迎大风降温 华南高温', 'n6.jpg', '前天14时的气温还有30℃，昨天14时就下降到了20.7℃，降幅近10℃。', '2015-10-29 08:09:46'),
(144, '社会', '王思聪助阵杨幂新戏首映 手挡镜头太羞涩', 'n7.jpg', '电影《我是证人》在北京举行首映礼，导演安尚勋携主演杨幂、鹿晗、王景春、朱亚文等亮相。', '2015-10-29 08:15:15'),
(145, '推荐', '菜鸟恋爱指南：约会成功的十大信号', 'n12.jpg', '', '2015-10-29 17:02:03'),
(146, '推荐', '近八成海归月薪低于1万，哪几类海归最吃香？', 'n17.jpg', '', '2015-10-29 17:02:03'),
(147, '推荐', '厦大开设“乳房美学”课 集美大学教“斗鸡”', 'n19.jpg', '', '2015-10-29 17:02:57'),
(148, '推荐', '公安部:"猎狐"抓556名嫌疑人', 'n19.jpg', '', '2015-10-29 17:04:12'),
(149, '推荐', '明日股市三大猜想及应对策略', 'n20.jpg', '', '2015-10-29 17:05:09'),
(150, '推荐', '发到发生法斯蒂芬', 'n10.jpg', '', '2015-10-29 17:06:56'),
(151, '推荐', '放大法萨法地方', 'n9.jpg', '', '2015-10-29 17:07:28'),
(152, '推荐', '孤鸿寡鹄', 'n11.jpg', '', '2015-10-29 17:07:54'),
(153, '推荐', '重新保存本补充', 'n12.jpg', '', '2015-10-29 17:08:23'),
(154, '推荐', '第三方斯蒂芬', 'n13.jpg', '', '2015-10-29 17:08:44'),
(155, '', '让他让他问题', 'n14.jpg', '', '2015-10-29 17:09:16'),
(156, '娱乐', 'v字v字形吃v型吃v', 'n15.jpg', '', '2015-10-29 17:09:52'),
(157, '娱乐', '快捷开关卡还款', 'n16.jpg', '', '2015-10-29 17:10:08'),
(158, '娱乐', '日听日uret', 'n17.jpg', '', '2015-10-29 17:10:34'),
(159, '百家', '而他认为儿童让他v', 'n20.jpg', '', '2015-10-29 17:18:52'),
(160, '百家', '娄底市解放路口时间', 'n21.jpg', '', '2015-10-29 17:18:52'),
(161, '百家', '绿卡将发生发动机', 'n23.jpg', '', '2015-10-29 17:20:47'),
(162, '百家', '哦认为哦iru', 'n24.jpg', 'dsd', '2015-10-29 17:20:47'),
(163, '百家', '哦入耳我irupowe', 'n25.jpg', '', '2015-10-29 17:20:47'),
(164, '百家', '哦日为荣威', 'n26.jpg', '', '2015-10-29 17:20:47'),
(165, '百家', '发达发生大发', 'n27.jpg', '', '2015-10-29 17:22:03'),
(166, '百家', '的发生发送到发送到', 'n28.jpg', '', '2015-10-29 17:22:03'),
(167, '百家', 'iouterop', 'n29.jpg', 'ss', '2015-10-29 17:23:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=212;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
