$(function() {
	$.ajax({
		url: 'baiduMobile.php',
		type: 'get',
		data: {
			'load': 'onload'
		},
		success: function(response, status, xhr) {

			$.each(response, function(i, value) {
				$('.newsList').find('ul').append('<li class="clear"><a class=" clear"><img src="img/' + value.img + '"><span class="rightContent"><h3>' + value.title + '</h3><time>' + value.time + '</time></span></a></li>');
			});
		}
	});
});
// 点击更多
$('.toggleNav').click(function() {
	$('.toggle,.subNav,.navDisapear').slideUp();
	$('.forMore').html('更多<span class="icon-triangle-down"></span>');
});
$('.forMore').click(function() {
		$('.toggle,.subNav,.navDisapear').slideDown();
		$('.forMore').html('搞笑');
	})
	// 图片左转

var pictureMarginLeft = 0;
var pagerControl = false;
var picWidth = $('.pictureWrapper').width();
var picWidthPre = picWidth;
var pictureLength = $('.pictureList').find('a').length;

var childLengthPicture = pictureLength * picWidth;

var diffPicture = childLengthPicture - picWidth;
$('.pictureInner').find('img').css({
	width: picWidth,
	height: 'auto'
});

$(window).resize(function() {

	picWidth = $('.pictureWrapper').width();

	childLengthPicture = pictureLength * picWidth;
	diffPicture = childLengthPicture - picWidth;
	$('.pictureInner').find('img').css({
		width: picWidth,
		height: 'auto'
	});

	pictureMarginLeft = pictureMarginLeft / picWidthPre * picWidth;
	$('.pictureList').css({
		marginLeft: pictureMarginLeft
	});

	picWidthPre = picWidth;
});


// 自动轮播定时器

var timerLoad = setInterval(function() {
	pictureChangeLeft(1000);
}, 4000);



// 图片左转和右转函数
function pictureChangeLeft(intervalTime) {


	pictureMarginLeft = pagerControl ? marginLeftPager : $('.pictureList').css('marginLeft');

	pictureMarginLeft = parseInt(pictureMarginLeft);

	var numInner = $('.pictureInner').size();
	if (Math.abs(pictureMarginLeft) == diffPicture && numInner == 1) {
		var cloneListPicture = $('.pictureInner').clone();


		$('.pictureInner').after(cloneListPicture);
		$('.pictureList:not(:animated)').animate({
			marginLeft: pictureMarginLeft - picWidth
		}, intervalTime);

	} else if (Math.abs(pictureMarginLeft) == childLengthPicture) {



		$('.pictureList').css('marginLeft', '0');
		$('.pictureInner:eq(1)').remove();
		$('.pictureList:not(:animated)').animate({
			marginLeft: -picWidth
		}, intervalTime);

	} else {
		$('.pictureList:not(:animated)').animate({
			marginLeft: pictureMarginLeft - picWidth
		}, intervalTime);

	}
}

// 分类载入新闻
var liClicked = $('.nav').find('li:not(.forMore)');
var navQuery = '';
liClicked.click(function() {
	var navQuery = $(this).text();

	$.ajax({
		url: 'navQuery.php',
		type: 'get',
		data: {
			nav: navQuery
		},
		success: function(response, status, xhr) {

			$.each(response, function(i, value) {
				$('.newsList').find('ul').append('<li class="clear"><a class=" clear"><img src="img/' + value.img + '"><span class="rightContent"><h3>' + value.title + '</h3><time>' + value.time + '</time></span></a></li>').find('li').css({
					opacity: 0
				}).animate({
					opacity: 1
				}, 1000);
			});
		}
	});



});
$(document).ajaxStart(function() {
	$('.loading').show();
	$('.newsList').find('ul').html('');
});
$(document).ajaxStop(function() {
	$('.loading').hide();
});