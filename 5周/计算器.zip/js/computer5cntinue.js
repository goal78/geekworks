var btn0 = document.getElementById('btn0');
var btn1 = document.getElementById('btn1');
var btn2 = document.getElementById('btn2');
var btn3 = document.getElementById('btn3');
var btn4 = document.getElementById('btn4');
var btn5 = document.getElementById('btn5');
var btn6 = document.getElementById('btn6');
var btn7 = document.getElementById('btn7');
var btn8 = document.getElementById('btn8');
var btn9 = document.getElementById('btn9');
var btnC = document.getElementById('btnC');
var btnTimes = document.getElementById('btnTimes');
var btnEqual = document.getElementById('btnEqual');
var btnDivide = document.getElementById('btnDivide');
var btnPlus = document.getElementById('btnPlus');
var btnMinus = document.getElementById('btnMinus');
var screenContent = document.getElementById('screenContent');
var btnArray = [btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btnC, btnTimes, btnDivide, btnPlus, btnMinus, btnEqual];


var btnNumber = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
var operatorArray = ['+', '-', 'x', '÷', '='];
var operatorArray2 = ['+', '-', 'x', '÷'];

var lastClickBtn;
var currentClickBtn = 0;
var result = 0;
var startIndex = 0;
var operatorCount = 0;
var screenFieldStartFor = '';
for (var i = 0; i < btnArray.length; i++) {

    btnArray[i].onclick = function() {

        var btnText = this.innerHTML;
        currentClickBtn = parseInt(btnText);
        var screenField = screenContent.innerHTML;
        var screenLengh = screenField.length;

        if (screenContent.innerHTML == '') {
            if (btnNumber.indexOf(currentClickBtn) >= 0) {
                screenContent.innerHTML = btnText;
            }


        } else if (btnNumber.indexOf(lastClickBtn) >= 0 && operatorArray.indexOf(btnText) >= 0) {

            var splitPoint;
            if (operatorCount == 0) {

                screenFieldStartFor = screenField;

            } else {
                screenFieldStartFor = screenField.slice(screenLengh - 1 - startIndex);
            }

            for (var h = 0; h < screenFieldStartFor.length; h++) {
                if (operatorArray2.indexOf(screenFieldStartFor.charAt(h)) >= 0) {
                    operatorCount += 1;
                    if (operatorCount == 1) {
                        startIndex = h;
                        splitPoint = screenFieldStartFor.charAt(h);
                        var screenArr = screenFieldStartFor.split(splitPoint);
                        var x1 = screenArr[0];
                        var y1 = screenArr[1];
                        x1 = Number(x1);
                        y1 = Number(y1);

                        var method = splitPoint;

                        result = calculate(x1, y1, method);


                    } else if (operatorCount >= 2) {

                        x1 = result;


                        var method = screenFieldStartFor.charAt(h);
                        var y1 = screenFieldStartFor.slice(h + 1);

                        y1 = Number(y1);
                        result = calculate(x1, y1, method);

                    }
                }
            }

            if (operatorArray2.indexOf(btnText) >= 0) {
                screenContent.innerHTML += btnText;
            } else {
                screenContent.innerHTML = result;
                result = 0;
                operatorCount = 0;
            }



        } else if (btnText == '=' && isNaN(screenField) == false) {

            screenContent.innerHTML += '';
        } else if (lastClickBtn == '=' && btnNumber.indexOf(currentClickBtn) >= 0) {


            screenContent.innerHTML = currentClickBtn;
            result = 0;
            operatorCount = 0;

        } else if (operatorArray2.indexOf(lastClickBtn) >= 0 && operatorArray.indexOf(btnText) >= 0) {
            screenContent.innerHTML += '';

        } else if (btnText == 'C') {
            screenContent.innerHTML = 0;
            result = 0;
            operatorCount = 0;

        } else if (lastClickBtn == 'C') {
            if (btnNumber.indexOf(currentClickBtn) >= 0) {
                screenContent.innerHTML = currentClickBtn;
            } else if (operatorArray2.indexOf(btnText)) {
                screenContent.innerHTML += btnText;
            }

        } else {
            screenContent.innerHTML += btnText;
        }


        if (btnNumber.indexOf(currentClickBtn) >= 0) {


            lastClickBtn = currentClickBtn;

        } else {

            lastClickBtn = btnText;
            beforeLastClickBtn = lastClickBtn;

        }


    }

};


var calculate = function(x, y, operator) {
    var x = x;
    var y = y;
    var operator = operator;
    var result;
    if (operator == '+') {
        result = x + y;
    } else if (operator == 'x') {
        result = x * y;
    } else if (operator == '-') {
        result = x - y;
    } else {
        result = x / y;
    }
    return result;
}