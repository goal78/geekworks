// 学生成绩
var scores = {
	student1: 8,
	student2: 92,
	student3: 75,
	student4: 54,
	student5: 37,
	student6: 16,
	student7: 21,
	student8: 43,
	student9: 63,
	student10: 88,
	student11: 100,
}
var grade = [];
for (i in scores) {
	switch (true) {
		case scores[i] < 20:
			grade.push(i + " 得分为" + scores[i] + " 被开除" + "\n");
			break;
		case scores[i] >= 20 && scores[i] < 40:
			grade.push(i + " 得分为" + scores[i] + " 被劝退" + "\n");
			break;
		case scores[i] >= 40 && scores[i] < 60:
			grade.push(i + " 得分为" + scores[i] + " 是不及格的学生" + "\n");
			break;
		case scores[i] >= 60 && scores[i] < 70:
			grade.push(i + " 得分为" + scores[i] + " 是及格的学生" + "\n");
			break;
		case scores[i] >= 70 && scores[i] < 80:
			grade.push(i + " 得分为" + scores[i] + " 是中等生" + "\n");
			break;
		case scores[i] >= 80 && scores[i] < 90:
			grade.push(i + " 得分为" + scores[i] + " 是良等生" + "\n");
			break;
		case scores[i] >= 90 && scores[i] < 100:
			grade.push(i + " 得分为" + scores[i] + " 是优等生" + "\n");
			break;
		default:
			grade.push(i + " 得分为" + scores[i] + " 是全国第一名");
			break;
	}
}
alert(grade);