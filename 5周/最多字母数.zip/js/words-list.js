// 装载字母对象
var words = {
	1: 'a',
	2: 'x',
	3: 'b',
	4: 'd',
	5: 'm',
	6: 'a',
	7: 'k',
	8: 'm',
	9: 'p',
	10: 'j',
	11: 'a'
}


// 新建对象，装载 字母=>个数
var wordCount = {};
// 分别计算每个字母出现的次数，并放入内容为 字母=>个数 的新建对象wordCount中
// 声明每个字母的个数
var numA = 0;
var numX = 0;
var numB = 0;
var numD = 0;
var numM = 0;
var numK = 0;
var numP = 0;
var numJ = 0;

for (var i in words) {

	switch (true) {
		case words[i] == 'a':
			numA++;
			wordCount.a = numA;
			break;
		case words[i] == 'x':
			numX++;
			wordCount.x = numX;
			break;
		case words[i] == 'b':
			numB++;
			wordCount.b = numB;
			break;
		case words[i] == 'd':
			numD++;
			wordCount.d = numD;
			break;
		case words[i] == 'm':
			numM++;
			wordCount.m = numM;
			break;
		case words[i] == 'k':
			numK++;
			wordCount.k = numK;
			break;
		case words[i] == 'p':
			numP++;
			wordCount.p = numP;
			break;
		default:
			numJ++;
			wordCount.j = numJ;

	}
}
// 计算出现最多字母的次数
var maxNum = Math.max(numA, numX, numB, numD, numM, numK, numP, numJ);
// 找出出现次数最多的字母
var maxWord = '';

for (var i in wordCount) {
	if (wordCount[i] == maxNum) {
		var maxWord = i;
	}
}
// 出现最多字母的位置
var position = 0;
var positionStr = '';
for (var i in words) {
	position++;
	if (words[i] == maxWord) {
		positionStr += position + '位，';
	}
}


// 弹出题目答案
alert('出现最多的字母' + maxWord + ',个数为' + maxNum + ',出现在对象里的位置分别为' + positionStr + '谢谢您对此作业的批改。');