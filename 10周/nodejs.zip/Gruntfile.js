// Generated on 2015-12-20 using
// generator-webapp 1.1.0
'use strict';

// # Globbing
// for performance reasons we're only matching one level down:
// 'test/spec/{,*/}*.js'
// If you want to recursively match all subfolders, use:
// 'test/spec/**/*.js'

module.exports = function (grunt) {

  // Time how long tasks take. Can help when optimizing build times
  require('time-grunt')(grunt);

  // Automatically load required grunt tasks
  require('jit-grunt')(grunt);

  // Configurable paths
  var config = {
    app: 'app',
    dist: 'dist'
  };

  // Define the configuration for all the tasks
  grunt.initConfig({

    // Project settings
    config: config,

    // Watches files for changes and runs tasks based on the changed files
    watch: {
      bower: {
        files: ['bower.json'],
        tasks: ['wiredep']
      },
      gruntfile: {
        files: ['Gruntfile.js']
      },
      compass: {
        files: ['<%= config.app %>/styles/{,*/}*.{scss,sass}'],
        tasks: ['compass']
      }
    },

    browserSync: {
      options: {
        notify: false,
        background: true,
        watchOptions: {
          ignored: ''
        }
      },
      livereload: {
        options: {
          files: [
            '<%= config.app %>/{,*/}*.html',
            '.tmp/styles/{,*/}*.css',
            '<%= config.app %>/images/{,*/}*',
            '.tmp/scripts/{,*/}*.js'
          ],
          port: 9000,
          server: {
            baseDir: ['.tmp', config.dist],
            routes: {
              '/bower_components': './bower_components'
            }
          }
        }
      },
      dist: {
        options: {
          background: false,
          server: '<%= config.dist %>'
        }
      }
    },

    // Empties folders to start fresh
    clean: {
      dist: {
        files: [{
          dot: true,
          src: [
            '.tmp',
            '<%= config.dist %>/*',
            '!<%= config.dist %>/.git*'
          ]
        }]
      },
      server: '.tmp'
    },
    compass:{
      dev: {                    // Another target 
        options: {
          sassDir: '<%= config.app %>/styles',
          cssDir: '<%= config.app %>/stylesheets'
        }
      }
    },
    
 	cssmin: {
        dist: {
           files: {
             '<%= config.dist %>/styles/geek.css': [             
             '<%= config.app %>/stylesheets/bootstrap.min.css',
             '<%= config.app %>/stylesheets/geek.css'
          ]
        }
      }
    },

    htmlmin: {
      dist: {
        options: {
          collapseBooleanAttributes: true,
          collapseWhitespace: true,
          conservativeCollapse: true,
          removeAttributeQuotes: true,
          removeCommentsFromCDATA: true,
          removeEmptyAttributes: true,
          removeOptionalTags: true,
          // true would impact styles with attribute selectors
          removeRedundantAttributes: false,
          useShortDoctype: true
        },
        files: [{
          expand: true,
          cwd: '<%= config.dist %>',
          src: '{,*/}*.html',
          dest: '<%= config.dist %>'
        }]
      }
    },

    uglify: {
      dist: {
        files: {
          
          '<%= config.dist %>/scripts/university.js': ['<%= config.app %>/scripts/university.js'],
          '<%= config.dist %>/scripts/roadPath.js': ['<%= config.dist %>/scripts/roadPath.js'],
          '<%= config.dist %>/scripts/media.js': ['<%= config.app %>/scripts/media.js'],
          '<%= config.dist %>/scripts/lessonList.js': ['<%= config.app %>/scripts/lessonList.js'],
          '<%= config.dist %>/scripts/learnSystem.js': ['<%= config.app %>/scripts/learnSystem.js'],
          '<%= config.dist %>/scripts/headerAni.js': ['<%= config.app %>/scripts/headerAni.js'],
          '<%= config.dist %>/scripts/geekPictureAni.js': ['<%= config.app %>/scripts/geekPictureAni.js'],
          '<%= config.dist %>/scripts/companies.js': ['<%= config.app %>/scripts/companies.js']
       
        }
      }
    },
   
    // Copies remaining files to places other tasks can use
    copy: {
      dist: {
        files: [{
          expand: true,
          dot: true,
          cwd: '<%= config.app %>',
          dest: '<%= config.dist %>',
          src: [
            'images/{,*/}*.{jpg,png}',
            '{,*/}*.html',
            'fonts/{,*/}*.*',
            'scripts/*.js'
          ]
        }, {
          expand: true,
          dot: true,
          cwd: '.',
          src: 'bower_components/bootstrap-sass/assets/fonts/bootstrap/*',
          dest: '<%= config.dist %>'
        }]
      }
    },

    // Run some tasks in parallel to speed up build process
    concurrent: {
      server: [
        'compass',
      ],
      dist: [
        'compass'
      ]
    }
  });


  grunt.registerTask('serve', 'start the server and preview your app', function (target) {

    if (target === 'dist') {
      return grunt.task.run(['build', 'browserSync:dist']);
    }

    grunt.task.run([
      'clean:server',
      'concurrent:server',
      'browserSync:livereload',
      'copy:dist',
      'watch'
    ]);
  });


  grunt.registerTask('build', [
    'clean:dist',
    'compass',
    'concurrent:dist',
    'cssmin',
    'copy:dist',
    'uglify',
    'htmlmin'
  ]);

  grunt.registerTask('default', [
    'build'
  ]);
};
