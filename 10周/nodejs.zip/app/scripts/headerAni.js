define(
	function(require, exports, module) {

		exports.headerAni = function (){
			// 头部搜索框变化
$('.formInput').focus(function() {
	$('.hoverInput').hide();
	$('.formSub').css("background", "#35b558 url(http://s1.jikexueyuan.com/common/images/topsearch-icon2_8c8d8b0.png) center center no-repeat");

});
$('.formInput').blur(function() {
	$('.hoverInput').show();
	$('.formSub').css("background", "url(http://s1.jikexueyuan.com/common/images/topsearch-icon_e1f5df2.png) center center no-repeat");

});

// 账户名鼠标悬浮效果
$('.accountName').hover(function() {
	$('.nameDown').show();
	$('.glyphicon-menu-down').addClass('glyphiconAni');
	$('.glyphicon-menu-down').removeClass('glyphiconAniDown');
}, function() {
	$('.nameDown').hide();
	$('.glyphicon-menu-down').addClass('glyphiconAniDown');
	$('.glyphicon-menu-down').removeClass('glyphiconAni');
});
$('.nameDown').hover(function() {
	$(this).css('display', 'block');
}, function() {
	$(this).hide();
});
		}
		
		// var geek = require('geek');
		// alert(geek);
	}
);