define(
	function(require, exports, module) {

		exports.lessonList = function (){
			// 课程浮动效果
var indexLi = 0;
var zindex = 303;
$('.courseNav').find('li').hover(function() {

	if ($(this).parent().find('li:first') != $(this) && $(this).parent().find('li:first').hasClass('on')) {
		$(this).parent().find('li:first').removeClass('on');
	}

	indexLi = $(this).index();
	$(this).addClass('on');

	$('.lesson' + indexLi).css('zIndex', zindex);
	zindex++

}, function() {
	$(this).removeClass('on');


});

$('.lesson').find('.liInner').hover(function() {
	$(this).css('zIndex', '500');
	$(this).find('p').slideDown();
}, function() {
	$(this).find('p').slideUp();
	$(this).css('zIndex', '400');

});

$('.picture').hover(function(){
$(this).find('imgInner').animate({opacity:0.3});
$(this).find('.videoIcon').animate({opacity:1});
$(this).find('.heart').animate({opacity:1});

},function(){
	$(this).find('imgInner').animate({opacity:0});
$(this).find('.videoIcon').animate({opacity:0});
$(this).find('.heart').animate({opacity:0});
});

		}

	}
);