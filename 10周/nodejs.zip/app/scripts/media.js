define(
	function(require, exports, module) {

		exports.media = function (){
			// 媒体左右箭头轮转
$('.mediaReportBody').hover(function() {
	$('.mediaLeft').animate({
		opacity: 1
	});
	$('.mediaRight').animate({
		opacity: 1
	});
}, function() {
	$('.mediaLeft').animate({
		opacity: 0
	});
	$('.mediaRight').animate({
		opacity: 0
	});
})



var childLength = $('.mediaList').find('a').length * 160;

var diff = childLength - 960;

$('.mediaLeft').click(function() {
	var mediaMarginLeft = $('.mediaList').css('marginLeft');
	mediaMarginLeft = parseInt(mediaMarginLeft);
	var numInner = $('.mediaListInner').size();
	if (Math.abs(mediaMarginLeft) == diff && numInner == 1) {
		var cloneList = $('.mediaListInner').clone();


		$('.mediaListInner').after(cloneList);
		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft - 160
		});
	} else if (Math.abs(mediaMarginLeft) == childLength) {



		$('.mediaList').css('marginLeft', '0');
		$('.mediaListInner:eq(1)').remove();
		$('.mediaList:not(:animated)').animate({
			marginLeft: -160
		});

	} else {
		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft - 160
		});

	}

});



$('.mediaRight').click(function() {
	var mediaMarginLeft = $('.mediaList').css('marginLeft');
	mediaMarginLeft = parseInt(mediaMarginLeft);
var numInner = $('.mediaListInner').size();
	if (mediaMarginLeft == 0 && numInner == 1) {
		var cloneList = $('.mediaListInner').clone();


		$('.mediaListInner').before(cloneList);
		$('.mediaList').css('marginLeft', -childLength + 'px');


		$('.mediaList:not(:animated)').animate({
			marginLeft: -childLength + 160
		});
	} else if (mediaMarginLeft == -diff) {

		$('.mediaListInner:eq(1)').remove();

		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft + 160
		});



	} else {
		$('.mediaList:not(:animated)').animate({
			marginLeft: mediaMarginLeft + 160
		});

	}

});
		}


	}
);