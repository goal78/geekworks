define(
	function(require, exports, module) {

		exports.companies = function (){
		$('.enterpriseBody').hover(function() {
	$('.companyLeft').animate({
		opacity: 1
	});
	$('.companyRight').animate({
		opacity: 1
	});
}, function() {
	$('.companyLeft').animate({
		opacity: 0
	});
	$('.companyRight').animate({
		opacity: 0
	});
})

var childLengthCompany = $('.companyList').find('a').length * 160;

var diffCompany = childLengthCompany - 960;

$('.companyLeft').click(function() {
	var companyMarginLeft = $('.companyList').css('marginLeft');
	companyMarginLeft = parseInt(companyMarginLeft);
	var numInner = $('.companyListInner').size();
	if (Math.abs(companyMarginLeft) == diffCompany && numInner == 1) {
		var cloneList = $('.companyListInner').clone();


		$('.companyListInner').after(cloneList);
		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft - 160
		});
	} else if (Math.abs(companyMarginLeft) == childLengthCompany) {



		$('.companyList').css('marginLeft', '0');
		$('.companyListInner:eq(1)').remove();
		$('.companyList:not(:animated)').animate({
			marginLeft: -160
		});

	} else {
		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft - 160
		});

	}

});



$('.companyRight').click(function() {
	var companyMarginLeft = $('.companyList').css('marginLeft');
	companyMarginLeft = parseInt(companyMarginLeft);
var numInner = $('.companyListInner').size();
	if (companyMarginLeft == 0 && numInner == 1) {
		var cloneList = $('.companyListInner').clone();


		$('.companyListInner').before(cloneList);
		$('.companyList').css('marginLeft', -childLengthCompany + 'px');


		$('.companyList:not(:animated)').animate({
			marginLeft: -childLengthCompany + 160
		});
	} else if (companyMarginLeft == -diffCompany) {

		$('.companyListInner:eq(1)').remove();

		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft + 160
		});



	} else {
		$('.companyList:not(:animated)').animate({
			marginLeft: companyMarginLeft + 160
		});

	}

});



	}

});



