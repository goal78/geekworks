define(
	function(require, exports, module) {

		exports.roadPath = function (){
			// 路线图浮动效果
$('.projectBody a').hover(function() {

	$(this).find('button').css({
		color: 'white',
		background: '#35b558',
		transition: 'all 1s'
	}, 1000);
}, function() {

	$(this).find('button').css({
		color: '#35b558',
		background: '#f3fff6',
		transition: 'all 1s'
	}, 1000);
});
		}
		

	}
);